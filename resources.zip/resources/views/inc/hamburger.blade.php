<nav class="nav js-nav">
    <ul class="nav-list">
        <li class="nav-item">
            <a href="{{ url('/index') }}" class="nav-link">TOP</a>
        </li>
        <li class="nav-item">
            <a href="https://www.facebook.com/facebook/" target="_blank" class="nav-link">Facebook</a>
        </li>
        <li class="nav-item">
            <a href="https://twitter.com/twitter" target="_blank" class="nav-link">Twitter</a>
        </li>
    </ul>
</nav>