<?php $__env->startSection('content'); ?>
		
	<!-- include hamburger menu  -->
	<?php echo $__env->make('inc.hamburger', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
    <!--start l-contents-->
    <div class="l-container u-clear">

        <!--start l-main-->
        <main class="l-main js-main">
            <div class="l-main-block"></div>
               <div class="archive">
                    <ul class="archive-list">
                    	<?php if(count($allArticle) > 0): ?>
                    		<?php $__currentLoopData = $allArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                    <li class="archive-item">
			                        <article class="card">
			                            <a href="<?php echo e(url('/single/' . $value->id)); ?>" class="card-link">
			                                <img src="<?php echo e(asset('/storage/images/' . $value->image)); ?>" alt="" class="card-image">
			                                <div class="card-bottom">
			                                    <h1 class="card-title"><?php echo e($value->title); ?></h1>
			                                    <time class="card-date" datetime="<?php echo e($value->posted_date); ?>">
			                                        <?php echo e($value->posted_date); ?>

			                                    </time>
			                                </div>
			                            </a>
			                        </article>
			                    </li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            <?php else: ?>
			            	<li class="archive-item">
		                        <article class="card">
		                            <a href="#" class="card-link">
		                                <img src="" alt="" class="card-image">
		                                <div class="card-bottom">
		                                    <h1 class="card-title sns">No article posted</h1>
		                                </div>
		                            </a>
		                        </article>
		                    </li>
		                <?php endif; ?>
	                </ul>
	            </div>
           		<a href="<?php echo e(url('/archive' )); ?>" class="archive-button">
	                <div class="button">
					    <p class="button-text">More</p>
					</div>
	            </a>
		    </div>
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>