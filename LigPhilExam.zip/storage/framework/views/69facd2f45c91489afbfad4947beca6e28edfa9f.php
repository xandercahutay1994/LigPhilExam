<?php $__env->startSection('content'); ?>
    <!--start l-contents-->
    <div class="l-container u-clear">

        <!--start l-main-->
        <main class="l-main js-main">
            <div class="l-main-block"></div>
            <a href="<?php echo e(url('/adminPosts')); ?>" class="l-main-button">
                <div class="button">
                    <p class="button-text">New Article</p>
                </div>
            </a>
            <ul class="archive archive-admin">
                <!-- check if there is an article -->
                <?php if(count($allArticle) > 0): ?>
                    <!-- Loop all posted article -->
                    <?php $__currentLoopData = $allArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="archive-item">
                            <a href="<?php echo e(url('/adminPosts/' . $value->id )); ?>" class="post-article">
                                <time class="post-article-date" datetime="<?php echo e($value->posted_date); ?>">                    <?php echo e($value->posted_date); ?>

                                </time>
                                <h1 class="post-article-title"><?php echo e($value->title); ?></h1>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <li class="archive-item sns">
                        <h1 class="post-article-title"> No article posted </h1>
                    </li>
                <?php endif; ?>       
            </ul>
        </main>
        <!--end l-main-->

    </div>
    <!--end l-contents-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>