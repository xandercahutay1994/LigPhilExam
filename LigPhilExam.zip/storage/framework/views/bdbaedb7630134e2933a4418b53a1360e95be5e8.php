<?php $__env->startSection('content'); ?>
    <div class="l-header-top u-clear">
        <div class="l-header-logo">
            <a class="logo " href="<?php echo e(url('index')); ?>">
                <img src="assets/images/logo-admin.png" width="138" height="28" alt="BLOG"/>
            </a>
        </div>
        <div class="l-header-text">
            <p>ADMIN PAGE</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>