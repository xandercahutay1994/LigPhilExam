<?php $__env->startSection('content'); ?>
	
	<!-- include hamburger menu  -->
	<?php echo $__env->make('inc.hamburger', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<!--start l-contents-->
    <div class="l-container u-clear">

        <!--start l-main-->
        <main class="l-main js-main">
            <div class="l-main-block"></div>
                <div class="page-number">
                    Page <span ><?php echo e($article->currentPage()); ?>/<?php echo e($article->lastPage()); ?></span>
                </div>
                <div class="archive">
                    <ul class="archive-list">
                    	<!-- Check and loop all articles  -->
                	 	<?php if(count($article) > 0): ?>
                    		<?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        <li class="archive-item">
		                            <article class="card">
									    <a href="<?php echo e(url('/single/' . $value->id)); ?>" class="card-link">
									        <img src="<?php echo e(asset('/storage/images/' . $value->image)); ?>" alt="" class="card-image">
									        <div class="card-bottom">
									            <h1 class="card-title"><?php echo e($value->title); ?></h1>
									            <time class="card-date" datetime="<?php echo e($value->posted_date); ?>">
									                <?php echo e($value->posted_date); ?>

									            </time>
									        </div>
									    </a>
									</article>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            <?php else: ?>
			            	<li class="archive-item">
		                        <article class="card">
		                            <a href="#" class="card-link">
		                                <img src="" alt="" class="card-image">
		                                <div class="card-bottom">
		                                    <h1 class="card-title sns">No article posted</h1>
		                                </div>
		                            </a>
		                        </article>
		                    </li>
		                <?php endif; ?>
		                <!-- end if & loop -->
					</ul>
				</div>

				<!-- Pagination -->
		        <div class="paginate">
		        	<!-- if currentPage is 1 disable prev button and make it color gray -->
			        <a href="<?php echo e($article->url(1)); ?>" class="<?php echo e($article->currentPage() == 1 ? 'paginate-prev is-disable' : 'paginate-prev'); ?>">
			        	<span class="paginate-prev-arrow "></span>
			        </a>

			        <!-- loop in all items then display -->
			        <?php for($i = 1; $i <= $article->lastPage(); $i++): ?>
				        <span class="<?php echo e(($article->currentPage() == $i) ? 'paginate-number is-current' : 'paginate-number'); ?>">
				            <a href="<?php echo e($article->url($i)); ?>"><?php echo e($i); ?></a>
				        </span>
				    <?php endfor; ?>

				    <!-- if currentPage = lastPage make next arrow disable and color gray the currentPage -->
			        <a href="<?php echo e($article->url($article->lastPage())); ?>" class="<?php echo e($article->currentPage() == $article->lastPage() ? 'paginate-next is-disable' : 'paginate-next'); ?>">
			        	<span class="paginate-next-arrow "></span>
			        </a>
                </div>
                <!-- end of pagination -->
			</div>
		</main>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>