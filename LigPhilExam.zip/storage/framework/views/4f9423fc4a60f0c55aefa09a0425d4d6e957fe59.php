<?php $__env->startSection('content'); ?>
    <!--start l-contents-->
    <div class="l-container u-clear">

        <!--start l-main-->
        <main class="l-main js-main">
            <div class="l-main-block"></div>
			<form method="POST" action="<?php echo e(url('/postSubmit')); ?>" class="form" enctype="multipart/form-data"	>
                <?php echo e(csrf_field()); ?>

                <label for="image" class="form-title">EYE CATCH IMAGE
                    <div class="form-file u-clear">
                        <span class="form-file-button">UPLOAD</span>
                    </div>
                </label>
                <input type="file" name="image" id="image" class="input input-image">
                <label for="title" class="form-title">TITLE</label>
                <div class="form-body">
                    <input type="text" id="title" name="title" class="input input-text">
                </div>
                <label for="contents" class="form-title">CONTENTS</label>
                <div class="form-textarea">
                    <textarea name="inquiry" id="inquiry" cols="30" rows="10" class="input input-contents"></textarea>
                </div>
                <!-- Error Message -->
                <div class="nav-item">
                    <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <label for="submit" class="form-button">
                    <div class="button">
					    <p class="button-text">Submit</p>
					</div>
                </label>
                <input type="submit" id="submit" class="input input-submit">
                <a href="<?php echo e(url('/articleLists')); ?>" class="form-button">
                    <div class="button">
					    <p class="button-text">Back</p>
					</div>
                </a>
            </form>
        </main>
        <!--end l-main-->

    </div>
    <!--end l-contents-->

    <!-- Form validation -->
    <script type="text/javascript">

    	$(document).ready(function(){
    		// Triggers when submit button is clicked
    		$('#submit').click(function(e){
	    		let image = $('#image').val();
	    		let title = $('#title').val();
	    		let inquiry = $('#inquiry').val();
	    		let count = 0;

	    		// Check if input fields are not empty
	    		if($('#image').val() == "" && title == "" && title == ""){
	    			console.log('hello');
	    			$('.nav-item').html('Error');
	    			e.preventDefault();
	    		}
	    	});
	    });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>